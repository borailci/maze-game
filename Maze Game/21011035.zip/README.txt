Lütfen ascii.txt , ascii2.txt , map1.txt , map2.txt, data.bin dosyalarını silmeyin. Programı bu dosyaların olduğu klasörde çalıştırın.
data.bin kullanıcı bilgilerini tutmaktadır. içerisinde hali hazırda kullanıcılar bulunmaktadır.
eğer boş bir liste istiyorsanız, dosyayı açıp içini temizleyiniz, dosyayı silmeyiniz!!!